
# Aviator Clone 🎮

A lightweight React + Tailwind demo of an Aviator-style "crash" game with animated plane, multiplier, and auto-cashout simulation.

## 🚀 Run locally
```bash
npm install
npm run dev
```
Then open http://localhost:5173/

## 🧩 Built with
- React 18 + Vite
- Tailwind CSS
- Framer Motion
