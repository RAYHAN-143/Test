
import React from "react";
import AviatorClone from "./components/AviatorClone";

export default function App() {
  return <AviatorClone />;
}
